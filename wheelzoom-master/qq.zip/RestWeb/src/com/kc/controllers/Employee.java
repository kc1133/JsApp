package com.kc.controllers;

public class Employee {
	int id;
	String name;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	/*@Overide
	public String toString(){
		System.out.println();
	}
*/
}
